package de.endrullis.idea.postfixtemplates.language.psi;

import com.intellij.psi.PsiNameIdentifierOwner;

public interface CptNamedElement extends PsiNameIdentifierOwner {
}
