package de.endrullis.idea.postfixtemplates.languages.dart;

import com.intellij.openapi.util.Condition;
import com.intellij.psi.PsiElement;

class DartPostfixTemplatesUtils {

	static final Condition<PsiElement> IS_ANY = element -> true;

}
