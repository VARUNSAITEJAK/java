package de.endrullis.idea.postfixtemplates.templates;

public interface NavigatablePostfixTemplate extends NavigatableTemplate {

	String getKey();
	
}
