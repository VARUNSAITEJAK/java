package de.endrullis.idea.postfixtemplates.utils;

public class FailedToCopyLocalTemplatesException extends RuntimeException {

	public FailedToCopyLocalTemplatesException(String message) {
		super(message);
	}

	public FailedToCopyLocalTemplatesException(Throwable cause) {
		super(cause);
	}

}
