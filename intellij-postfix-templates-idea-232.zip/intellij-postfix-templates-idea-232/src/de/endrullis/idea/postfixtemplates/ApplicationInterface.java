package de.endrullis.idea.postfixtemplates;

/**
 * @author Stefan Endrullis &lt;stefan@endrullis.de&gt;
 */
public interface ApplicationInterface {
}
