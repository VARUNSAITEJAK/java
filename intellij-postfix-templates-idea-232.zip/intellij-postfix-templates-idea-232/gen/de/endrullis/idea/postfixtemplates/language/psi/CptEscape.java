// This is a generated file. Not intended for manual editing.
package de.endrullis.idea.postfixtemplates.language.psi;

import com.intellij.psi.PsiElement;

public interface CptEscape extends PsiElement {

}
