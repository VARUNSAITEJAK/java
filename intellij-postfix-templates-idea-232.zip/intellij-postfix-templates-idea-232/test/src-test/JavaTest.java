package yaml;

public class JavaTest {

	void f() {
		"1".toInt<caret>
	}

}
